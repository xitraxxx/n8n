# n8n Taxi Bot – Render Deployment

## Instructions

1. Connecte ce repo à Render via "New Web Service"
2. Utilise `npm install` comme build command
3. Utilise `n8n` comme start command
4. Ajoute ces variables d'environnement :

- `N8N_BASIC_AUTH_ACTIVE=true`
- `N8N_BASIC_AUTH_USER=admin`
- `N8N_BASIC_AUTH_PASSWORD=passetaxi`
- `N8N_ENCRYPTION_KEY=ajskd89a8s7df98as7df97as8d7f9as87df9`
- `TELEGRAM_TOKEN=ton_token`
- `OPENROUTER_API_KEY=ta_cle_openrouter`
- `GOOGLE_SHEET_URL=ton_fichier_google_sheets`
- `TELEGRAM_CHAT_ID=ton_chat_id`